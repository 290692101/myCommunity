create definer = root@localhost view productcustomers as
select `sqltest`.`customers`.`cust_name`    AS `cust_name`,
       `sqltest`.`customers`.`cust_contact` AS `cust_contact`,
       `sqltest`.`orderitems`.`prod_id`     AS `prod_id`
from `sqltest`.`customers`
         join `sqltest`.`orders`
         join `sqltest`.`orderitems`
where ((`sqltest`.`customers`.`cust_id` = `sqltest`.`orders`.`cust_id`) and
       (`sqltest`.`orderitems`.`order_num` = `sqltest`.`orders`.`order_num`));


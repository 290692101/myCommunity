create definer = root@localhost view orderitemsexpanded as
select `sqltest`.`orderitems`.`prod_id`                                          AS `prod_id`,
       `sqltest`.`orderitems`.`quantity`                                         AS `quantity`,
       `sqltest`.`orderitems`.`item_price`                                       AS `item_price`,
       (`sqltest`.`orderitems`.`quantity` * `sqltest`.`orderitems`.`item_price`) AS `expanded_price`,
       `sqltest`.`orderitems`.`order_num`                                        AS `order_num`
from `sqltest`.`orderitems`;


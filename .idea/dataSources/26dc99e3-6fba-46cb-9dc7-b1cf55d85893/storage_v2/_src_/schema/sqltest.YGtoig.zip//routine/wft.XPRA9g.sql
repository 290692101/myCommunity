create
    definer = m290@`%` procedure wft(IN userName varchar(32), OUT id111 bigint, IN eMail varchar(50),
                                     IN realName varchar(50), IN roleIds varchar(200), IN passWord varchar(50))
begin
    #设置当前时间
    #向user表插入数据
    INSERT INTO user0319(userName,passWord,userEmail,realName)
    VALUES (userName,passWord ,eMail,realName);
    #获取自增主键
    select LAST_INSERT_ID() INTO id111;
    #保存用户和角色的关系数据

    SET roleIds=CONCAT(',',roleIds,',');
    
    
    INSERT INTO user_role0329(user_id, role_id)
    #将自增得到的新的用户id值 和 查找到的角色id 插入ur表
    select id111,r.id
    from role0329 r
    #在roleId中查找有没有role表中的id 如果存在交集 则存入ur表
    #可能会插入多条数据哦
    WHERE INSTR(roleIds,CONCAT(',',id,','))>0;
end;


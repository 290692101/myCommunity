create definer = root@localhost trigger neworder
    after insert
    on orders
    for each row
    SELECT NEW.order_num
INTO @asd;


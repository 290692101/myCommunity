create definer = root@localhost view vendorlocations as
select concat(rtrim(`sqltest`.`vendors`.`vend_name`), '(', rtrim(`sqltest`.`vendors`.`vend_country`),
              ')') AS `vend_title`
from `sqltest`.`vendors`
order by `sqltest`.`vendors`.`vend_name`;


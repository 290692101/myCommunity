create definer = root@localhost view customeremaillist as
select `sqltest`.`customers`.`cust_id`    AS `cust_id`,
       `sqltest`.`customers`.`cust_name`  AS `cust_name`,
       `sqltest`.`customers`.`cust_email` AS `cust_email`
from `sqltest`.`customers`
where (`sqltest`.`customers`.`cust_email` is not null);


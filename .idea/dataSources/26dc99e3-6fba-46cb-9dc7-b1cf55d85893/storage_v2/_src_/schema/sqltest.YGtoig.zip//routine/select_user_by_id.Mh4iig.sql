create
    definer = m290@`%` procedure select_user_by_id(IN userId int(32), OUT userName varchar(32),
                                                   OUT passWord varchar(50), OUT eMail varchar(50),
                                                   OUT realName varchar(32))
begin
    /*根据用户id查询其他数据*/
    /*注意要用表别名来表示列 否则会出现混淆*/
    select u.userName,u.passWord,u.userEmail,u.realName
    INTO userName ,passWord,eMail,realName

    from user0319 u
        where userId=u.id;

end;

